//
//  OpenGLView.h
//  OpenGL ES_Practice_001
//
//  Created by zjjt on 16/9/20.
//  Copyright © 2016年 JackZhang. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#include <OpenGLES/ES2/gl.h>
#include <OpenGLES/ES2/glext.h>

@interface OpenGLView : UIView
{
    CAEAGLLayer *eaglLayer;
    EAGLContext *context;
    GLuint colorRenderBuffer;
    GLuint depthRenderBuffer;
    GLuint framebuffer;
}
@end
