//
//  OSGLKViewController.h
//  OpenGLES_Draw_Sphere
//
//  Created by xu jie on 16/9/25.
//  Copyright © 2016年 xujie. All rights reserved.
//

#import <GLKit/GLKit.h>

@interface OSGLKViewController : GLKViewController

@end
